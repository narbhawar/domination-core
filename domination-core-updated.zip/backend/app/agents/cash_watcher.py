def track_finance():
    # TODO: track MRR and burn rate
    return {'mrr': 0, 'burn': 0}
