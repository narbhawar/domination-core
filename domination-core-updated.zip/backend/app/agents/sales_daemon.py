def close_deal(conversation):
    # TODO: handle sales conversations and payments
    return 'sale closed'
