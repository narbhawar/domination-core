def design(asset_spec):
    # TODO: generate logo and social posts
    return 'design assets'
