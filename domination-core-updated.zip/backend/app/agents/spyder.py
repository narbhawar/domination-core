def monitor_trends():
    # TODO: monitor social and product platforms
    return ['trend1', 'trend2']
